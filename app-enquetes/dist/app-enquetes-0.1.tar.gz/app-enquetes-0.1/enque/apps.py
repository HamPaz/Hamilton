from django.apps import AppConfig


class EnqueConfig(AppConfig):
    name = 'enque'
